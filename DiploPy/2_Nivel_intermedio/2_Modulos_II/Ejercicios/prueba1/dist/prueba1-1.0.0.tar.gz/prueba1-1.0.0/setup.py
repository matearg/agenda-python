from distutils.core import setup

setup(
    name="prueba1",
    version="1.0.0",
    py_modules=["prueba1"],
    author="Mateo",
    author_email="mateoarcidiacono@gmail.com",
    url="nohay.com",
    description="Es una prueba de uso",
)
